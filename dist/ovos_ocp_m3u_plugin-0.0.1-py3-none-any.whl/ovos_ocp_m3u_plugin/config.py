
# valid settings under OCP section in mycroft.conf
OCPPlaylistExtractorConfig = {"m3u": {}}
